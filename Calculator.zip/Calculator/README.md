# Prabhat's Calculator - TechnoHacks

TECHNOHACKS-CALCULATOR

# Prabhat Sharma

Hello connections,

I'm excited to share #task3 of my internship with The TECHNOHACKS EDUTECH in Web development under the Technohacks - 'Lets Grow Together' Program.

#BATCH8

Task:CALCULATOR

IDE: VSCODE

Technologies Used:
- HTML
- CSS
- JAVASCRIPT

GitHub Repository Link:https://github.com/prabhatrsharma/TechnoHacks-Calculator.git 

Hosted Website Link: https://prabhatrsharma.github.io/TechnoHacks-Calculator/

To know MORE about TECHNOHACKS EDUTECH Website: http://technohacks.co.in/
VISIT Technohacks Edutech: 
<a href="https://www.linkedin.com/company/technohacks-edutech/"> Linkedin</a>||
<a href="https://twitter.com/technohacksedu"> Twitter</a>||
<a href="https://telegram.me/TechnoHacksofficial"> Telegram</a>||
<a href="https://www.instagram.com/technohacks.co.in"> Instagram</a>||
<a href="https://www.youtube.com/channel/UCwuh25VS9J9ApJ7Yomw_Lqw"> Youtube</a>||<br>

Thanking,

TechnoHacks:
Mr. Sandip Gavit

Please review and comment with your worthy suggestions.

Thank You!

Prabhat Sharma

![Screenshot (54)](https://github.com/prabhatrsharma/TechnoHacks-Calculator/assets/118990267/96437e4e-204d-4861-a64c-e3ab248de281)
